import pandas as pd 
from datasets import load_dataset
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch
from tqdm import tqdm
from multiprocessing import Pool
import pickle 
import numpy as np
from self_bleu import compute_self_bleu
import argparse
import re
import string
import random 
import time
import os 

FEWSHOT_SOURCES = [
    {
        "question": "There are 15 trees in the grove. Grove workers will plant trees in the grove today. After they are done, there will be 21 trees. How many trees did the grove workers plant today?",
        "answer": "There are 15 trees originally. Then there were 21 trees after some more were planted. So there must have been 21 - 15 = 6. So the answer is 6.",
        "short_answer": "6",
    },
    {
        "question": "If there are 3 cars in the parking lot and 2 more cars arrive, how many cars are in the parking lot?",
        "answer": "There are originally 3 cars. 2 more cars arrive. 3 + 2 = 5. So the answer is 5.",
        "short_answer": "5",
    },
    {
        "question": "Leah had 32 chocolates and her sister had 42. If they ate 35, how many pieces do they have left in total?",
        "answer": "Originally, Leah had 32 chocolates. Her sister had 42. So in total they had 32 + 42 = 74. After eating 35, they had 74 - 35 = 39. So the answer is 39.",
        "short_answer": "39",
    },
    {
        "question": "Jason had 20 lollipops. He gave Denny some lollipops. Now Jason has 12 lollipops. How many lollipops did Jason give to Denny?",
        "answer": "Jason started with 20 lollipops. Then he had 12 after giving some to Denny. So he gave Denny 20 - 12 = 8. So the answer is 8.",
        "short_answer": "8",
    },
    {
        "question": "Shawn has five toys. For Christmas, he got two toys each from his mom and dad. How many toys does he have now?",
        "answer": "Shawn started with 5 toys. If he got 2 toys each from his mom and dad, then that is 4 more toys. 5 + 4 = 9. So the answer is 9.",
        "short_answer": "9",
    },
    {
        "question": "There were nine computers in the server room. Five more computers were installed each day, from monday to thursday. How many computers are now in the server room?",
        "answer": "There were originally 9 computers. For each of 4 days, 5 more computers were added. So 5 * 4 = 20 computers were added. 9 + 20 is 29. So the answer is 29.",
        "short_answer": "29",
    },
    {
        "question": "Michael had 58 golf balls. On tuesday, he lost 23 golf balls. On wednesday, he lost 2 more. How many golf balls did he have at the end of wednesday?",
        "answer": "Michael started with 58 golf balls. After losing 23 on tuesday, he had 58 - 23 = 35. After losing 2 more, he had 35 - 2 = 33 golf balls. So the answer is 33.",
        "short_answer": "33",
    },
    {
        "question": "Olivia has $23. She bought five bagels for $3 each. How much money does she have left?",
        "answer": "Olivia had 23 dollars. 5 bagels for 3 dollars each will be 5 x 3 = 15 dollars. So she has 23 - 15 dollars left. 23 - 15 is 8. So the answer is 8.",
        "short_answer": "8",
    },
]

def run_generation_on_gpu(args):
    gpu_id, prompts_chunk, model_name = args

    # Set GPU
    torch.cuda.set_device(gpu_id)
    model = AutoModelForCausalLM.from_pretrained(model_name, device_map={"": gpu_id}, torch_dtype="auto")
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    results = []
    for idx, prompt in prompts_chunk:
        messages = [
            {"role": "user", "content": prompt},
        ]
        text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        inputs = tokenizer([text], return_tensors="pt").to(model.device)

        # Generate
        generated = model.generate(
            **inputs,
            max_new_tokens=1024,
            do_sample=True,
            top_p=0.9,
            temperature=0.1,
        )
        input_ids = inputs.input_ids
        generated_suffix = []
        for inp, out in zip(input_ids, generated):
            # drop the input portion
            generated_suffix.append(out[len(inp):])

        # Decode
        response = tokenizer.batch_decode(generated_suffix, skip_special_tokens=True)[0]
        results.append((idx, response))
    return results

def dpo_dataset(model_name, savename, is_partial=False):
    print(model_name)
    # Load model & tokenizer
    f = pd.read_json("gsm_data/train.jsonl", lines=True)
    generation = {"chosen": [], "prompt": [], "rejected": []}
    prompts = f.augmented_prompt.tolist()
    df = {"prompt": [], "response": []}
    indexed_prompts = list(enumerate(prompts))
    num_gpus = torch.cuda.device_count()
    chunks = [indexed_prompts[i::num_gpus] for i in range(num_gpus)]
    args = [(i, chunk, model_name) for i, chunk in enumerate(chunks)]
    with Pool(num_gpus) as p:
        all_outputs = list(tqdm(p.map(run_generation_on_gpu, args), total=num_gpus))

    flat_outputs = [item for sublist in all_outputs for item in sublist]
    flat_outputs.sort(key=lambda x: x[0])
    responses = [x[1] for x in flat_outputs]
    df["prompt"] = prompts
    df["response"] = responses
    df = pd.DataFrame(df)

    os.makedirs(f"math/gsm_{savename}", exist_ok=True)
    df.to_json(f"math/gsm_{savename}/train.jsonl", lines=True, orient="records")

def ppo_dataset():
    f = pd.read_json("gsm_data/train.jsonl", lines=True)
    ppo_df = {"augmented_prompt": [], "base_prompt": [], "rubric": []}
    # Example prompt setup (chat-style)
    for i, row in f.iterrows():
        ppo_df["augmented_prompt"].append(row.augmented_prompt)
        ppo_df["base_prompt"].append(row.partial_prompt)
        rubric = f"You are a helpful math assistant, that evaluates another assistant's response based on how accurately the response solves the given problem. Here's the correct response: {row.augmented_response}\n\nGive a score between 1 and 5 based on partial correctness. 1 if the reasoning is poor, and 5 if the reasoning is correct and the answer is correct. Only response with a number between 1 and 5 and do not provide an explanation.\n\nUser: {row.augmented_prompt}\nAssistant: "
        print(rubric, "\n\n")
        ppo_df["rubric"].append(rubric)
    ppo_df = pd.DataFrame(ppo_df)
    ppo_df.to_json("math/gsm_ppo/train.jsonl",lines=True,orient="records")

def dataset():
    ds = load_dataset("openai/gsm8k", "main")
    train_df = ds["train"].to_pandas() 
    # dpo = {prompt, chosen, rejected}
    # partial_dpo (answer for a partial prompt), random_dpo (answer for a swapped prompt)
    test_df = ds["test"].to_pandas()
    examples = [f"Example {i+1}:\n" + f"Question: {x['question']}\nAnswer: {x['answer']}\n#### {x['short_answer']}" for i, x in enumerate(FEWSHOT_SOURCES)]
    examples = "\n\n".join(examples)
    PROMPT = "You are a helpful math assistant. Solve the following problem step-by-step and give the final answer after ####.\n\n" + examples
    df = {"partial_prompt": [], "augmented_prompt": [], "augmented_response": [], "numeric_response": []}
    n = 0
    for i, row in train_df.iterrows():
        tick = time.time()
        question = row.question 
        questions = question.split(".")
        question_list = questions[:-1]
        if len(question_list) < 1:
            print("Skipped...")
            n += 1
            continue 
        idx = random.randrange(len(question_list))
        picked = question_list[idx]
        remaining = question_list[:idx] + question_list[idx+1:]
        partial_question = ".".join(remaining) + "." + questions[-1]
        partial_question = partial_question.strip()
        df["augmented_prompt"].append(PROMPT + "\n\nNew question: " + row.question)
        df["partial_prompt"].append(PROMPT + "\n\nNew question: " + partial_question)
        df["augmented_response"].append(row.answer)
        answer = row.answer.split("####")[1]
        num = re.search(r"\d+\.?\d*", answer).group()
        num = float(num)
        df["numeric_response"].append(num)
        print("Idx: ", i, " Time: ", time.time() - tick)
    df = pd.DataFrame(df)
    print("Skipped .... ", n)
    df.to_json("gsm_data/train.jsonl", lines=True, orient="records")

def evaluate(model_name):
    # Load model & tokenizer
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype="auto",
        device_map="auto"  # will place layers automatically (useful for multi-GPU or CPU/GPU mix)
    )
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    f = pd.read_json("gsm_data/test.jsonl", lines=True)
    f = f.sample(n=200, random_state=42, replace=False)
    f = f.reset_index(drop=True)
    generation = {"prompt": [], "response": [], "numeric_response": []}
    # Example prompt setup (chat-style)
    for i, row in f.iterrows():
        tick = time.time()
        messages = [
            {"role": "user", "content": row.augmented_prompt.strip()},
        ]
        # Use the chat template helper in the tokenizer to build the input string
        text = tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True
        )

        # Tokenize and move to model device
        inputs = tokenizer([text], return_tensors="pt").to(model.device)

        # Generate
        generated = model.generate(
            **inputs,
            max_new_tokens=5012,
            do_sample=True, 
            top_p=0.9,
            temperature=0.1,
        )

        # The output includes the entire sequence (input + response). We trim the input prefix.
        # (You can also separately generate only the suffix.)
        input_ids = inputs.input_ids
        generated_suffix = []
        for inp, out in zip(input_ids, generated):
            # drop the input portion
            generated_suffix.append(out[len(inp):])

        # Decode
        response = tokenizer.batch_decode(generated_suffix, skip_special_tokens=True)[0]
        print("Response:", response)
        generation["prompt"].append(row.augmented_prompt.strip())
        generation["response"].append(response)
        num = 0
        try:
            answer = response.split("####")[1]
            num = re.search(r"\d+\.?\d*", answer).group()
            num = float(num)
        except:
            messages = [
                {"role": "user", "content": "Extract the numeric answer from this reasoning, and do not include anythig else in your response other than the number. " + response}
                ]
            # Use the chat template helper in the tokenizer to build the input string
            text = tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True
            )

            inputs = tokenizer([text], return_tensors="pt").to(model.device)

            # Generate
            generated = model.generate(
                **inputs,
                max_new_tokens=1024,
                do_sample=True, 
                top_p=0.9,
                temperature=0.1,
            )

            input_ids = inputs.input_ids
            generated_suffix = []
            for inp, out in zip(input_ids, generated):
                # drop the input portion
                generated_suffix.append(out[len(inp):])

            # Decode
            response = tokenizer.batch_decode(generated_suffix, skip_special_tokens=True)[0]
            try:
                num = re.search(r"\d+\.?\d*", response).group()
                num = float(num)
            except:
                num = np.inf
        generation["numeric_response"].append(num)
        print("Extracted answer: ", num, " true answer: ", row.numeric_response)
        print("Time: ", time.time() - tick)
    generation = pd.DataFrame(generation)
    pred_answer = generation.numeric_response
    true_answer = f.numeric_response
    acc = len(np.where(true_answer == pred_answer)[0]) / len(pred_answer)
    print("Model name: ", model_name)
    print("Acc: ", acc)
    with open("math/gsm.txt", "a") as f:
        f.write(model_name + " Acc: " + str(acc) + f" sample size: {len(pred_answer)}\n\n")


if __name__ == "__main__":
    for model in ["q3b_n5e-7_v2", "q3b_n5e-7_v3"]:
        evaluate(model_name = f"../contrastive_finetune/gsm/{model}")
