import pandas as pd 
from datasets import load_dataset
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch
from tqdm import tqdm
from multiprocessing import Pool
import pickle 
import numpy as np
from self_bleu import compute_self_bleu
import argparse
import re
import random 
import time
import os 

FEWSHOT_SOURCES = [
    {
        "question": "There are 15 trees in the grove. Grove workers will plant trees in the grove today. After they are done, there will be 21 trees. How many trees did the grove workers plant today?",
        "answer": "There are 15 trees originally. Then there were 21 trees after some more were planted. So there must have been 21 - 15 = 6. So the answer is 6.",
        "short_answer": "6",
    },
    {
        "question": "If there are 3 cars in the parking lot and 2 more cars arrive, how many cars are in the parking lot?",
        "answer": "There are originally 3 cars. 2 more cars arrive. 3 + 2 = 5. So the answer is 5.",
        "short_answer": "5",
    },
    {
        "question": "Leah had 32 chocolates and her sister had 42. If they ate 35, how many pieces do they have left in total?",
        "answer": "Originally, Leah had 32 chocolates. Her sister had 42. So in total they had 32 + 42 = 74. After eating 35, they had 74 - 35 = 39. So the answer is 39.",
        "short_answer": "39",
    },
    {
        "question": "Jason had 20 lollipops. He gave Denny some lollipops. Now Jason has 12 lollipops. How many lollipops did Jason give to Denny?",
        "answer": "Jason started with 20 lollipops. Then he had 12 after giving some to Denny. So he gave Denny 20 - 12 = 8. So the answer is 8.",
        "short_answer": "8",
    },
    {
        "question": "Shawn has five toys. For Christmas, he got two toys each from his mom and dad. How many toys does he have now?",
        "answer": "Shawn started with 5 toys. If he got 2 toys each from his mom and dad, then that is 4 more toys. 5 + 4 = 9. So the answer is 9.",
        "short_answer": "9",
    },
    {
        "question": "There were nine computers in the server room. Five more computers were installed each day, from monday to thursday. How many computers are now in the server room?",
        "answer": "There were originally 9 computers. For each of 4 days, 5 more computers were added. So 5 * 4 = 20 computers were added. 9 + 20 is 29. So the answer is 29.",
        "short_answer": "29",
    },
    {
        "question": "Michael had 58 golf balls. On tuesday, he lost 23 golf balls. On wednesday, he lost 2 more. How many golf balls did he have at the end of wednesday?",
        "answer": "Michael started with 58 golf balls. After losing 23 on tuesday, he had 58 - 23 = 35. After losing 2 more, he had 35 - 2 = 33 golf balls. So the answer is 33.",
        "short_answer": "33",
    },
    {
        "question": "Olivia has $23. She bought five bagels for $3 each. How much money does she have left?",
        "answer": "Olivia had 23 dollars. 5 bagels for 3 dollars each will be 5 x 3 = 15 dollars. So she has 23 - 15 dollars left. 23 - 15 is 8. So the answer is 8.",
        "short_answer": "8",
    },
]

# Is partial is deprecated
def dpo_dataset(model_checkpoint="", is_partial=False):
    model_name = "Qwen/Qwen2.5-1.5B-Instruct"
    print(model_name)
    savename = "qwen1b"
    # Load model & tokenizer
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype="auto",
        device_map="auto"  # will place layers automatically (useful for multi-GPU or CPU/GPU mix)
    )
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    f = pd.read_json("svamp_data/train.jsonl", lines=True)
    generation = {"chosen": [], "prompt": [], "rejected": []}
    # Example prompt setup (chat-style)
    for i, row in f.iterrows():
        print(i)
        tick = time.time()
        messages = [
            {"role": "user", "content": row.augmented_prompt.strip()},
            # {"role": "user", "content": row.base_prompt.strip()},
        ]
        print(i, len(f), "\n\n")
        # Use the chat template helper in the tokenizer to build the input string
        text = tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True
        )

        # Tokenize and move to model device
        inputs = tokenizer([text], return_tensors="pt").to(model.device)

        # Generate
        generated = model.generate(
            **inputs,
            max_new_tokens=1024,
            do_sample=True, 
            top_p=0.9,
            temperature=0.1,
        )

        # The output includes the entire sequence (input + response). We trim the input prefix.
        # (You can also separately generate only the suffix.)
        input_ids = inputs.input_ids
        generated_suffix = []
        for inp, out in zip(input_ids, generated):
            # drop the input portion
            generated_suffix.append(out[len(inp):])

        # Decode
        response = tokenizer.batch_decode(generated_suffix, skip_special_tokens=True)[0]
        print("Response:", response)
        generation["prompt"].append(row.augmented_prompt.strip())
        generation["chosen"].append(response)

        if is_partial:
            messages = [
            {"role": "user", "content": row.partial_prompt.strip()},
            ]
            # Use the chat template helper in the tokenizer to build the input string
            text = tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True
            )

            # Tokenize and move to model device
            inputs = tokenizer([text], return_tensors="pt").to(model.device)

            # Generate
            generated = model.generate(
                **inputs,
                max_new_tokens=1024,
                do_sample=True, 
                top_p=0.9,
                temperature=0.1,
            )

            input_ids = inputs.input_ids
            generated_suffix = []
            for inp, out in zip(input_ids, generated):
                # drop the input portion
                generated_suffix.append(out[len(inp):])

            # Decode
            response = tokenizer.batch_decode(generated_suffix, skip_special_tokens=True)[0]
            print("Response:", response)
            generation["rejected"].append(response)
        print("Time: ", (time.time() - tick)/60, i)
    
    gsm_df = pd.read_json(f'math/gsm_{savename}/train.jsonl', lines=True)
    
    gsm_df = gsm_df.sample(n=700, replace=False, random_state=42)
    if not is_partial:
        generation["rejected"] = generation["chosen"].copy()
        random.shuffle(generation["rejected"])
    generation = pd.DataFrame(generation)
    generation = pd.concat([generation, gsm_df])
    print(len(generation))
    if is_partial:
        os.makedirs(f"math/svamp_{savename}_partial", exist_ok=True)
        generation.to_json(f"math/svamp_{savename}_partial/train.jsonl", lines=True, orient="records")
    else:
        os.makedirs(f"rebuttal/svamp/{savename}", exist_ok=True)
        generation.to_json(f"rebuttal/svamp/{savename}/train.jsonl", lines=True, orient="records")

def ppo_dataset():
    f = pd.read_json("svamp_data/train.jsonl", lines=True)
    ppo_df = {"augmented_prompt": [], "base_prompt": [], "rubric": []}
    # Example prompt setup (chat-style)
    for i, row in f.iterrows():
        ppo_df["augmented_prompt"].append(row.augmented_prompt)
        ppo_df["base_prompt"].append(row.partial_prompt)
        augmented_response = row.augmented_response + "\n#### " + str(row.numeric_response)
        rubric = f"You are a helpful math assistant, that evaluates another assistant's response based on how accurately the response solves the given problem. Here's the correct response: {augmented_response}\n\nGive a score between 1 and 5 based on partial correctness. 1 if the reasoning is poor, and 5 if the reasoning is correct and the answer is correct. Only response with a number between 1 and 5 and do not provide an explanation.\n\nUser: {row.augmented_prompt}\nAssistant: "
        ppo_df["rubric"].append(rubric)
    ppo_df = pd.DataFrame(ppo_df)
    original_df = pd.read_json("math/gsm_ppo/train.jsonl",lines=True)
    ppo_df = pd.concat([ppo_df, original_df.sample(n=700, replace=False, random_state=42)])
    ppo_df.to_json("math/svamp_ppo/train.jsonl",lines=True,orient="records")

def dataset():
    ds = load_dataset("ChilleD/SVAMP")
    train_df = ds["train"].to_pandas() 
    # dpo = {prompt, chosen, rejected}
    # partial_dpo (answer for a partial prompt), random_dpo (answer for a swapped prompt)
    test_df = ds["test"].to_pandas()
    examples = [f"Example {i+1}:\n" + f"Question: {x['question']}\nAnswer: {x['answer']}\n#### {x['short_answer']}" for i, x in enumerate(FEWSHOT_SOURCES)]
    examples = "\n\n".join(examples)
    PROMPT = "You are a helpful math assistant. Solve the following problem step-by-step and give the final answer after ####.\n\n" + examples
    # df = {"augmented_prompt": [], "augmented_response": [], "numeric_response": []}
    df = {"partial_prompt": [], "augmented_prompt": [], "augmented_response": [], "numeric_response": []}
    n = 0
    for i, row in train_df.iterrows():
        question = row.question_concat
        partial_question = row.Question
        equation = row.Equation
        answer = row.Answer
        df["augmented_prompt"].append(PROMPT + "\n\nNew question: " + question)
        df["partial_prompt"].append(PROMPT + "\n\nNew question: " + partial_question)
        df["augmented_response"].append(equation)
        df["numeric_response"].append(answer)
    df = pd.DataFrame(df)
    print("Skipped .... ", n)
    df.to_json("svamp_data/train.jsonl", lines=True, orient="records")

def evaluate(model_name):
    # Load model & tokenizer
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype="auto",
        device_map="auto"  # will place layers automatically (useful for multi-GPU or CPU/GPU mix)
    )
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    f = pd.read_json("svamp_data/test.jsonl", lines=True)
    f = f.reset_index(drop=True)
    generation = {"prompt": [], "response": [], "numeric_response": []}
    # Example prompt setup (chat-style)
    for i, row in f.iterrows():
        tick = time.time()
        print(row.augmented_prompt.strip())
        messages = [
            {"role": "user", "content": row.augmented_prompt.strip()},
        ]
        # Use the chat template helper in the tokenizer to build the input string
        text = tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True
        )

        # Tokenize and move to model device
        inputs = tokenizer([text], return_tensors="pt").to(model.device)

        # Generate
        generated = model.generate(
            **inputs,
            max_new_tokens=1024,
            do_sample=True, 
            top_p=0.9,
            temperature=0.1,
        )

        # The output includes the entire sequence (input + response). We trim the input prefix.
        # (You can also separately generate only the suffix.)
        input_ids = inputs.input_ids
        generated_suffix = []
        for inp, out in zip(input_ids, generated):
            # drop the input portion
            generated_suffix.append(out[len(inp):])

        # Decode
        response = tokenizer.batch_decode(generated_suffix, skip_special_tokens=True)[0]
        print("Response:", response)
        generation["prompt"].append(row.augmented_prompt.strip())
        generation["response"].append(response)
        try:
            answer = response.split("####")[1]
            num = re.search(r"\d+\.?\d*", answer).group()
            num = float(num)
        except:
            messages = [
                {"role": "user", "content": "Extract the numeric answer from this reasoning, and do not include anythig ele in your response other than the number. " + response}
                ]
            # Use the chat template helper in the tokenizer to build the input string
            text = tokenizer.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True
            )

            # Tokenize and move to model device
            inputs = tokenizer([text], return_tensors="pt").to(model.device)

            # Generate
            generated = model.generate(
                **inputs,
                max_new_tokens=1024,
                do_sample=True, 
                top_p=0.9,
                temperature=0.1,
            )

            input_ids = inputs.input_ids
            generated_suffix = []
            for inp, out in zip(input_ids, generated):
                # drop the input portion
                generated_suffix.append(out[len(inp):])

            # Decode
            response = tokenizer.batch_decode(generated_suffix, skip_special_tokens=True)[0]
            try:
                num = re.search(r"\d+\.?\d*", response).group()
                num = float(num)
            except:
                num = np.inf
        generation["numeric_response"].append(num)
        print("Time: ", time.time() - tick)
    generation = pd.DataFrame(generation)
    pred_answer = generation.numeric_response
    true_answer = f.numeric_response
    acc = len(np.where(true_answer == pred_answer)[0]) / len(pred_answer)
    print("Model name: ", model_name)
    print("Acc: ", acc)
    with open("math/svamp.txt", "a") as f:
        f.write(model_name + " Acc: " + str(acc) + f" sample size: {len(pred_answer)}\n\n")


if __name__ == "__main__":
    evaluate(model_name=f"../contrastive_finetune/svamp/l1b_n1e-7")
    evaluate(model_name=f"../contrastive_finetune/svamp/l1b_n5e-7")
    evaluate(model_name=f"../contrastive_finetune/svamp/l1b_n1e-6")
