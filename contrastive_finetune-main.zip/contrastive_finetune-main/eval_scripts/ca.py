import pandas as pd
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch
from tqdm import tqdm
from multiprocessing import Pool
import pickle 
import numpy as np
from self_bleu import compute_self_bleu
import argparse
import re 

def generate(model_checkpoint, save_name):
    model_name ="/gscratch/socialrl/hjnam/contrastive_finetune/ca/" + model_checkpoint
    # Load model & tokenizer
    print(model_name)
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype="auto",
        device_map="auto"  # will place layers automatically (useful for multi-GPU or CPU/GPU mix)
    )
    tokenizer = AutoTokenizer.from_pretrained(model_name)

    f = pd.read_json("/gscratch/socialrl/hjnam/kl_personalization/community_alignment/test.jsonl",lines=True)
    generation = {"base_prompt": [], "response": [], "augmented_prompt": []}
    # Example prompt setup (chat-style)
    for i, row in f.iterrows():
        messages = [
            {"role": "user", "content": row.augmented_prompt.strip()}
        ]
        print(i, len(f), "\n\n")
        # Use the chat template helper in the tokenizer to build the input string
        text = tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True
        )

        # Tokenize and move to model device
        inputs = tokenizer([text], return_tensors="pt").to(model.device)

        # Generate
        generated = model.generate(
            **inputs,
            max_new_tokens=512,
            do_sample=True, 
            top_p=0.9,
            temperature=0.1,
        )

        # The output includes the entire sequence (input + response). We trim the input prefix.
        # (You can also separately generate only the suffix.)
        input_ids = inputs.input_ids
        generated_suffix = []
        for inp, out in zip(input_ids, generated):
            # drop the input portion
            generated_suffix.append(out[len(inp):])

        # Decode
        response = tokenizer.batch_decode(generated_suffix, skip_special_tokens=True)[0]
        print("Response:", response)
        generation["augmented_prompt"].append(row.augmented_prompt.strip())
        generation["response"].append(response)
        generation["base_prompt"].append(row.base_prompt.strip())
    generation = pd.DataFrame(generation)

    generation.to_json(f"results/community_alignment_{save_name}.jsonl", lines=True, orient="records")


def evaluate_with_rubric(result_file, use_qwen=False):
    f = pd.read_json(result_file + ".jsonl", lines=True)
    rubrics = pd.read_json("/gscratch/socialrl/hjnam/kl_personalization/community_alignment/test.jsonl",lines=True)
    # rubrics = pd.read_json("/gscratch/socialrl/hjnam/kl_personalization/community_alignment/train.jsonl",lines=True)
    
    scores = []
    if use_qwen:
        model_name = "Qwen/Qwen2.5-14B-Instruct"
        # model_name = "Qwen/Qwen2.5-7B-Instruct"
    else:
        model_name = "meta-llama/Meta-Llama-3-8B-Instruct"
        
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype="auto",
        device_map="auto"  # will place layers automatically (useful for multi-GPU or CPU/GPU mix)
    )
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    
    scores = []
    for i, row in rubrics.iterrows():
        prompt = row.augmented_prompt
        # response = f.iloc[i].chosen[1]["content"] # eval ground truth response
        response = f.iloc[i].response # eval policy reward
        # response = row.chosen_response # chosen - eval rm
        # response = np.random.choice(row.rejected_responses) # rejected - eval rm
        response_scores = []
        for rubric in rubrics.iloc[i].instructions:
            messages = [{"role": "system", "content": f"You are a helpful assistant, that evaluates another assistant's response based on how well the response is personalized to this user based on their stated preference. Give a score between 1 and 5, 1 if the response is general, and 5 if the response sufficiently addresses the user's preference. Only respond with a number between 1 and 5 and do not provide an explanation."},
                {"role": "user", "content": f"User: {prompt}\n\nAssistant: {response}\n\nUser's preference: {rubric}"}]
            # print(messages)
            # Use the chat template helper in the tokenizer to build the input string
            text = tokenizer.apply_chat_template(
                    messages,
                    tokenize=False,
                    add_generation_prompt=True
                )

            # Tokenize and move to model device
            inputs = tokenizer([text], return_tensors="pt").to(model.device)

            # Generate
            generated = model.generate(
                    **inputs,
                    max_new_tokens=4,
                    do_sample=True, 
                    top_p=0.9,
                    temperature=0.1,
                )

            # The output includes the entire sequence (input + response). We trim the input prefix.
            # (You can also separately generate only the suffix.)
            input_ids = inputs.input_ids
            generated_suffix = []
            for inp, out in zip(input_ids, generated):
                # drop the input portion
                generated_suffix.append(out[len(inp):])
            
            # Decode
            score_string = tokenizer.batch_decode(generated_suffix, skip_special_tokens=True)[0]
            score = 0
            try:
                score = int(re.search(r'\d+', score_string).group())
                # score = int(score_string)
            except Exception as e:
                print(e)
                print(score_string, "\n\n")
            response_scores.append(score)
        scores.append(np.mean(response_scores))

    f["score"] = scores
    # rubrics["score"] = scores
    print("Mean: ", np.mean(f["score"]), " STD: ", np.std(f["score"]))
    if use_qwen:
        f.to_json(f"{result_file}_qwen14b_scored.jsonl",lines=True,orient="records")
    else:
        f.to_json(f"{result_file}_llama8b_scored.jsonl",lines=True,orient="records")

def main():
    parser = argparse.ArgumentParser(description="Example script with argparse")

    # Add arguments
    parser.add_argument("--save_name", type=str, default="")
    parser.add_argument("--model_checkpoint", type=str, default="")
    parser.add_argument("--use_qwen", action="store_true", default=False, help="Use toy domain for eval")

    args = parser.parse_args()

    save_name = args.save_name
    generate(model_checkpoint=args.model_checkpoint, save_name = save_name)
    evaluate_with_rubric(result_file=f"results/community_alignment_{save_name}", use_qwen=args.use_qwen)
    if args.use_qwen:
        f = pd.read_json(f"results/community_alignment_{save_name}_qwen14b_scored.jsonl",lines=True)
        gpt = pd.read_json("community_alignment/test_chosen_qwen14b_scored.jsonl", lines=True)
    else:
        f = pd.read_json(f"results/community_alignment_{save_name}_llama8b_scored.jsonl",lines=True)
        gpt = pd.read_json("community_alignment/test_chosen_llama8b_scored.jsonl", lines=True)
    win_rate = len(np.where(f.score >= gpt.score)[0]) / len(f.score) * 100
    # bleu = compute_self_bleu(f.response.tolist())
    print("Win rate: ", win_rate, save_name)
    # print("BLEU: ", bleu)
    with open("ablations_icml/results_ca.txt", "a") as f:
         f.write(args.model_checkpoint + " " + args.save_name + " " + str(win_rate) + "\n\n")

if __name__ == "__main__":
    main()



