import pandas as pd
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch
from tqdm import tqdm
from multiprocessing import Pool
import pickle 
import numpy as np
from self_bleu import compute_self_bleu
import argparse

def generate(model_checkpoint, is_toy, save_name):
    # model_name = model_checkpoint # "Qwen/Qwen2.5-1.5B-Instruct"
    model_name = "/gscratch/socialrl/hjnam/contrastive_finetune/" + model_checkpoint
    print(model_name)
    # model_name = "meta-llama/Llama-3.2-1B-Instruct"
    # model_name = "meta-llama/Meta-Llama-3-8B-Instruct"
    # Load model & tokenizer
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype="auto",
        device_map="auto"  # will place layers automatically (useful for multi-GPU or CPU/GPU mix)
    )
    tokenizer = AutoTokenizer.from_pretrained(model_name)

    if is_toy:
        f = pd.read_json("toy_1105/test.jsonl", lines=True)
    else:
        f = pd.read_json("multi_bench/rubric_ppo/test.jsonl", lines=True)
    generation = {"base_prompt": [], "response": [], "augmented_prompt": []}
    # Example prompt setup (chat-style)
    for i, row in f.iterrows():
        messages = [
            {"role": "user", "content": row.augmented_prompt.strip()},
            # {"role": "user", "content": row.base_prompt.strip()},
        ]
        print(i, len(f), "\n\n")
        # Use the chat template helper in the tokenizer to build the input string
        text = tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True
        )

        # Tokenize and move to model device
        inputs = tokenizer([text], return_tensors="pt").to(model.device)

        # Generate
        generated = model.generate(
            **inputs,
            max_new_tokens=1024,
            do_sample=True, 
            top_p=0.9,
            temperature=0.1,
        )

        # The output includes the entire sequence (input + response). We trim the input prefix.
        # (You can also separately generate only the suffix.)
        input_ids = inputs.input_ids
        generated_suffix = []
        for inp, out in zip(input_ids, generated):
            # drop the input portion
            generated_suffix.append(out[len(inp):])

        # Decode
        response = tokenizer.batch_decode(generated_suffix, skip_special_tokens=True)[0]
        print("Response:", response)
        generation["augmented_prompt"].append(row.augmented_prompt.strip())
        generation["response"].append(response)
        generation["base_prompt"].append(row.base_prompt.strip())
    generation = pd.DataFrame(generation)
    # generation.to_json("results/toy_sft_qwen1b.jsonl",lines=True, orient="records")
    if is_toy:
        domain = "toy"
    else:
        domain = "mb"
    generation.to_json(f"results/{domain}_{save_name}.jsonl", lines=True, orient="records")


def evaluate(result_file, use_qwen=False):
    if "qwen" in result_file or use_qwen:
        # model_name = "Qwen/Qwen2.5-7B-Instruct"
        model_name = "Qwen/Qwen2.5-14B-Instruct"
    else:
        model_name = "meta-llama/Meta-Llama-3-8B-Instruct"
    # Load model & tokenizer
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype="auto",
        device_map="auto"  # will place layers automatically (useful for multi-GPU or CPU/GPU mix)
    )
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    df = pd.read_json(f"results/{result_file}.jsonl", lines=True)
    scores = []
    for i, row in df.iterrows():
        prompt = row.augmented_prompt
        response = row.response
        messages = [{"role": "system", "content": f"You are a helpful assistant, that evaluates another assistant's response based on how well the response is personalized to this user based on their stated preference. Give a score between 1 and 5, 1 if the response is general, and 5 if the response sufficiently addresses the user's preference. Only respond with a number between 1 and 5 and do not provide an explanation."},
                {"role": "user", "content": f"User: {prompt}\n\nAssistant: {response}"}]

        # Use the chat template helper in the tokenizer to build the input string
        text = tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True
        )

        # Tokenize and move to model device
        inputs = tokenizer([text], return_tensors="pt").to(model.device)

        # Generate
        generated = model.generate(
            **inputs,
            max_new_tokens=1024,
            do_sample=True, 
            top_p=0.9,
            temperature=0.1,
        )

        # The output includes the entire sequence (input + response). We trim the input prefix.
        # (You can also separately generate only the suffix.)
        input_ids = inputs.input_ids
        generated_suffix = []
        for inp, out in zip(input_ids, generated):
            # drop the input portion
            generated_suffix.append(out[len(inp):])

        # Decode
        response = tokenizer.batch_decode(generated_suffix, skip_special_tokens=True)[0]
        print("Response:", response)
        try:
            score = int(response)
            scores.append(score)
        except Exception as e:
            print(e)
            print(response, "\n\n")
            scores.append(0)

    df["score"] = scores
    if "qwen" in result_file or use_qwen:
        df.to_json(f"results/qwen14b/{result_file}_qwen14b_scored.jsonl",lines=True,orient="records")
    else:
        df.to_json(f"results/{result_file}_llama8b_scored.jsonl",lines=True,orient="records")
    print(result_file, "Mean: ", np.mean(df["score"]), " STD: ", np.std(df["score"]))

def evaluate_with_rubric(result_file, rubric_file, use_qwen=False):
    f = pd.read_json(f"results/{result_file}.jsonl", lines=True)
    rubrics = pd.read_json(f"{rubric_file}.jsonl", lines=True)

    scores = []
    if "qwen" in result_file or use_qwen:
        model_name = "Qwen/Qwen2.5-14B-Instruct"
        # model_name = "Qwen/Qwen2.5-7B-Instruct"
    else:
        model_name = "meta-llama/Meta-Llama-3-8B-Instruct"
        
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype="auto",
        device_map="auto"  # will place layers automatically (useful for multi-GPU or CPU/GPU mix)
    )
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    
    scores = []
    for i, row in f.iterrows():
        prompt = row.augmented_prompt
        response = row.response
        response_scores = []
        for rubric in rubrics.iloc[i].rubric:
            messages = [{"role": "system", "content": f"You are a helpful assistant, that evaluates another assistant's response based on how well the response is personalized to this user based on their stated preference. Give a score between 1 and 5, 1 if the response is general, and 5 if the response sufficiently addresses the user's preference. Only respond with a number between 1 and 5 and do not provide an explanation."},
                {"role": "user", "content": f"User: {prompt}\n\nAssistant: {response}\n\nUser's preference: {rubric}"}]
            print(messages)
            # Use the chat template helper in the tokenizer to build the input string
            text = tokenizer.apply_chat_template(
                    messages,
                    tokenize=False,
                    add_generation_prompt=True
                )

            # Tokenize and move to model device
            inputs = tokenizer([text], return_tensors="pt").to(model.device)

            # Generate
            generated = model.generate(
                    **inputs,
                    max_new_tokens=256,
                    do_sample=True, 
                    top_p=0.9,
                    temperature=0.1,
                )

            # The output includes the entire sequence (input + response). We trim the input prefix.
            # (You can also separately generate only the suffix.)
            input_ids = inputs.input_ids
            generated_suffix = []
            for inp, out in zip(input_ids, generated):
                # drop the input portion
                generated_suffix.append(out[len(inp):])
            
            # Decode
            score_string = tokenizer.batch_decode(generated_suffix, skip_special_tokens=True)[0]
            
            try:
                score = int(score_string)
            except Exception as e:
                print(e)
                print(score_string, "\n\n")
            response_scores.append(score)
        scores.append(np.mean(response_scores))

    f["score"] = scores
    print(result_file, "Mean: ", np.mean(f["score"]), " STD: ", np.std(f["score"]))
    if use_qwen:
        f.to_json(f"results/qwen14b/{result_file}_qwen14b_scored.jsonl",lines=True,orient="records")
    else:
        f.to_json(f"results/{result_file}_llama8b_scored.jsonl",lines=True,orient="records")


"""
save_name = "llama8b_pos"
generate(model_checkpoint="checkpoint/llama8b_sft_pos_mb", is_toy=False, save_name=save_name)
evaluate(result_file = f"results/mb_{save_name}")
f = pd.read_json(f"results/mb_{save_name}_llama8b_scored.jsonl",lines=True)
gpt = pd.read_json("results/mb_gpt4o_llama8b_scored.jsonl",lines=True)
print("Win rate: ", len(np.where(f.score >= gpt.score)[0]) / len(gpt.score)*100)
bleu = compute_self_bleu(f.response.tolist())
print("BLEU: " , bleu)
"""

"""
save_name = "qwen7b_both"
generate(model_checkpoint="checkpoint/qwen7b_sft_both_mb", is_toy=False, save_name=save_name)
evaluate(result_file = f"results/mb_{save_name}", use_qwen=True)
f = pd.read_json(f"results/mb_{save_name}_qwen7b_scored.jsonl",lines=True)
gpt = pd.read_json("results/mb_gpt4o_qwen7b_scored.jsonl",lines=True)
print("Win rate: ", len(np.where(f.score >= gpt.score)[0]) / len(gpt.score)*100)
bleu = compute_self_bleu(f.response.tolist())
print("BLEU: " , bleu)
"""


def main():
    parser = argparse.ArgumentParser(description="Example script with argparse")

    # Add arguments
    parser.add_argument("--save_name", type=str, default="")
    parser.add_argument("--model_checkpoint", type=str, default="")
    parser.add_argument("--is_toy", action="store_true", default=False, help="Use toy domain for eval")
    parser.add_argument("--use_qwen", action="store_true", default=False, help="Use toy domain for eval")

    args = parser.parse_args()

    save_name = args.save_name
    
    generate(model_checkpoint=args.model_checkpoint, is_toy=args.is_toy, save_name=args.save_name)
    if args.is_toy:
        evaluate_with_rubric(result_file = f"toy_{save_name}", rubric_file="toy_1105/test", use_qwen=args.use_qwen)
    else:
        evaluate(result_file = f"mb_{save_name}", use_qwen=args.use_qwen)
    
    if args.is_toy:
        if args.use_qwen:
            f = pd.read_json(f"results/qwen14b/toy_{save_name}_qwen14b_scored.jsonl",lines=True)
            gpt = pd.read_json("results/toy_1105_gpt4o_qwen14b_scored.jsonl",lines=True)
        else:
            f = pd.read_json(f"results/toy_{save_name}_llama8b_scored.jsonl",lines=True)
            gpt = pd.read_json("results/toy_1105_gpt4o_llama8b_scored.jsonl",lines=True)
    else:
        if args.use_qwen:
            f = pd.read_json(f"results/qwen14b/mb_{save_name}_qwen14b_scored.jsonl",lines=True)
            gpt = pd.read_json("results/mb_gpt4o_qwen14b_scored.jsonl",lines=True)
        else:
            f = pd.read_json(f"results/mb_{save_name}_llama8b_scored.jsonl",lines=True)
            gpt = pd.read_json("results/mb_gpt4o_llama8b_scored.jsonl",lines=True)
    win_rate = len(np.where(f.score >= gpt.score)[0]) / len(gpt.score)*100
    
    print("Win rate: ", win_rate)
    
    with open("ablations_icml/results_mb.txt", "a") as f:
        f.write(args.model_checkpoint + " " + args.save_name + " " + str(win_rate) + "\n\n")


if __name__ == "__main__":
    main()
