import pandas as pd 
from datasets import load_dataset
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch
from tqdm import tqdm
from multiprocessing import Pool
import pickle 
import numpy as np
from self_bleu import compute_self_bleu
import argparse
import re
import string
import random 
import time
import os 

def run_generation_on_gpu(args):
    gpu_id, prompts_chunk, model_name = args

    # Set GPU
    torch.cuda.set_device(gpu_id)
    model = AutoModelForCausalLM.from_pretrained(model_name, device_map={"": gpu_id}, torch_dtype="auto")
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    results = []
    for idx, prompt in prompts_chunk:
        messages = [
            {"role": "user", "content": prompt},
        ]
        text = tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        inputs = tokenizer([text], return_tensors="pt").to(model.device)

        # Generate
        generated = model.generate(
            **inputs,
            max_new_tokens=1024,
            do_sample=True,
            top_p=0.9,
            temperature=1.0,
        )
        input_ids = inputs.input_ids
        generated_suffix = []
        for inp, out in zip(input_ids, generated):
            # drop the input portion
            generated_suffix.append(out[len(inp):])

        # Decode
        response = tokenizer.batch_decode(generated_suffix, skip_special_tokens=True)[0]
        results.append((idx, response))
    return results

def evaluate(model_name, level):
    if level == "challenge":
        ds = load_dataset("allenai/ai2_arc", "ARC-Challenge")
    elif level == "easy":
        ds = load_dataset("allenai/ai2_arc", "ARC-Easy")
    test_df = ds["test"].to_pandas()
    sample = test_df.sample(n=500, replace=False, random_state=42)
    labels = string.ascii_uppercase
    prompts = []
    answers = []
    for i, row in sample.iterrows():
        print(i)        
        question = row.question
        choices = row.choices["text"]
        prompt = "You are a helpful assistant. The following is a multiple choice question with answer choices. Your response should show clear and concise reasoning, and you should end with "f'"The answer is: <X>", where X is the correct letter choice.\n\n'
        prompt += question + "\n\n" + "\n".join(
                    f"{labels[i]}: {choice}" for i, choice in enumerate(choices)
                    )
        prompt += '\n\nYour response should end with 'f'"The answer is: <X>", where X is the correct letter choice.'
        print(prompt)
        answers.append(row.answerKey)
        prompts.append(prompt)
    print(len(prompts))
    df = {"response": [], "question": [], "answer": []}
    indexed_prompts = list(enumerate(prompts))
    num_gpus = torch.cuda.device_count()
    chunks = [indexed_prompts[i::num_gpus] for i in range(num_gpus)]
    args = [(i, chunk, model_name) for i, chunk in enumerate(chunks)]
    with Pool(num_gpus) as p:
        all_outputs = list(tqdm(p.map(run_generation_on_gpu, args), total=num_gpus))

    flat_outputs = [item for sublist in all_outputs for item in sublist]
    flat_outputs.sort(key=lambda x: x[0])
    responses = [x[1] for x in flat_outputs]
    df["question"] = prompts
    df["response"] = responses
    df["answer"] = answers
    df = pd.DataFrame(df)
    df["pred_answer"] = (
            df["response"]
            .astype(str)
            .str.split(r'(?i)the answer is', n=1, expand=True)[1]   # keep text AFTER marker
            .str.extract(r'\b([ABCD])\b', expand=False)              # extract first A/B/C/D
            .str.upper()
        )
    acc = len(np.where(df["pred_answer"] == df["answer"])[0])/ len(df["answer"])
    print(model_name, acc)
    if level == "challenge":
        with open("math/arc_challenge.txt", "a") as f:
            f.write(model_name + " Acc: " + str(acc) + f" sample size: {len(responses)}\n\n")
    elif level == "easy":
        with open("math/arc_easy.txt", "a") as f:
            f.write(model_name + " Acc: " + str(acc) + f" sample size: {len(responses)}\n\n")

def dpo_dataset(model_name, savename, level):
    if level == "challenge":
        ds = load_dataset("allenai/ai2_arc", "ARC-Challenge")
    elif level == "easy":
        ds = load_dataset("allenai/ai2_arc", "ARC-Easy")
    train_df = ds["train"].to_pandas()
    labels = string.ascii_uppercase
    prompts = []
    answers = []
    for i, row in train_df.iterrows():
        print(i)        
        question = row.question
        choices = row.choices["text"]
        prompt = "You are a helpful assistant. The following is a multiple choice question with answer choices. Your response should show clear and concise reasoning, and you should end with "f'"The answer is: <X>", where X is the correct letter choice.\n\n'
        prompt += question + "\n\n" + "\n".join(
                    f"{labels[i]}: {choice}" for i, choice in enumerate(choices)
                    )
        prompt += '\n\nYour response should end with 'f'"The answer is: <X>", where X is the correct letter choice.'
        print(prompt)
        answers.append(row.answerKey)
        prompts.append(prompt)
    print(len(prompts))
    indexed_prompts = list(enumerate(prompts))
    num_gpus = torch.cuda.device_count()
    chunks = [indexed_prompts[i::num_gpus] for i in range(num_gpus)]
    args = [(i, chunk, model_name) for i, chunk in enumerate(chunks)]
    with Pool(num_gpus) as p:
        all_outputs = list(tqdm(p.map(run_generation_on_gpu, args), total=num_gpus))

    flat_outputs = [item for sublist in all_outputs for item in sublist]
    flat_outputs.sort(key=lambda x: x[0])
    responses = [x[1] for x in flat_outputs]
    
    df = {"prompt": [], "chosen": [], "rejected": []}
    indexed_prompts = list(enumerate(prompts))
    num_gpus = torch.cuda.device_count()
    chunks = [indexed_prompts[i::num_gpus] for i in range(num_gpus)]
    args = [(i, chunk, model_name) for i, chunk in enumerate(chunks)]
    with Pool(num_gpus) as p:
        all_outputs = list(tqdm(p.map(run_generation_on_gpu, args), total=num_gpus))

    flat_outputs = [item for sublist in all_outputs for item in sublist]
    flat_outputs.sort(key=lambda x: x[0])
    responses = [x[1] for x in flat_outputs]
    df["prompt"] = prompts
    chosen = []
    rejected = []
    shuffled_responses = random.sample(responses, k=len(responses))
    for i, row in enumerate(responses):
        chosen.append([{"role": 'user', 'content': prompts[i]}, {"role": "assistant", "content": row}])
        rejected.append([{"role": 'user', 'content': prompts[i]}, {"role": "assistant", "content": shuffled_responses[i]}])
    df["chosen"] = chosen
    df["rejected"] = rejected
    df = pd.DataFrame(df)
    if level == "challenge":
        os.makedirs(f'arc/challenge/{savename}', exist_ok=True)
        df.to_json(f'arc/challenge/{savename}/train.jsonl', lines=True, orient="records")
    elif level == "easy":
        os.makedirs(f'arc/easy/{savename}', exist_ok=True)
        df.to_json(f'arc/easy/{savename}/train.jsonl', lines=True, orient="records")

def ppo_dataset(level):
    if level == "challenge":
        ds = load_dataset("allenai/ai2_arc", "ARC-Challenge")
    elif level == "easy":
        ds = load_dataset("allenai/ai2_arc", "ARC-Easy")
    train_df = ds["train"].to_pandas()
    labels = string.ascii_uppercase
    prompts = []
    rubrics = []
    for i, row in train_df.iterrows():
        print(i)        
        question = row.question
        choices = row.choices["text"]
        prompt = "You are a helpful assistant. The following is a multiple choice question with answer choices. Your response should show clear and concise reasoning, and you should end with "f'"The answer is: <X>", where X is the correct letter choice.\n\n'
        prompt += question + "\n\n" + "\n".join(
                    f"{labels[i]}: {choice}" for i, choice in enumerate(choices)
                    )
        prompt += '\n\nYour response should end with 'f'"The answer is: <X>", where X is the correct letter choice.'
        prompts.append(prompt)

        correct_answer = row.answerKey
        rubric = f"You are a helpful math assistant, that evaluates another assistant's response based on how accurately the response answers the given problem. Here's the correct answer: {correct_answer}\n\nGive a score between 1 and 5 based on partial correctness. 1 if the reasoning is poor, and 5 if the reasoning is correct and the answer is correct. Only response with a number between 1 and 5 and do not provide an explanation.\n\nUser: {prompt}\nAssistant: "
        rubrics.append(rubric) 
 
    ppo_df = {"augmented_prompt": [], "rubric": []}
    ppo_df["augmented_prompt"] = prompts
    ppo_df["rubric"] = rubrics
    ppo_df = pd.DataFrame(ppo_df)
    prompts = ppo_df["augmented_prompt"].tolist()
    shuffled_prompts = random.sample(prompts, k=len(prompts))
    ppo_df["base_prompt"] = shuffled_prompts 
    ppo_df.to_json(f"arc_{level}/train.jsonl",lines=True, orient="records")
    

if __name__ == "__main__":
    # ppo_dataset(level="challenge")
    # dpo_dataset("meta-llama/Llama-3.2-3B-Instruct", savename="llama3b", level="challenge")
    # evaluate("Qwen/Qwen2.5-7B-Instruct", level="easy")
   
