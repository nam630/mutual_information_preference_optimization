import pandas as pd
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch
from tqdm import tqdm
from multiprocessing import Pool
import pickle 
import numpy as np
from self_bleu import compute_self_bleu
import argparse

import re 

def extract_strings(obj):
    if isinstance(obj, dict):
        for v in obj.values():
            yield from extract_strings(v)
    elif isinstance(obj, list):
        for v in obj:
            yield from extract_strings(v)
    elif isinstance(obj, str):
        yield obj

def evaluate(generations, save_name, use_qwen):
    if use_qwen:
        model_name = "Qwen/Qwen2.5-14B-Instruct"
    else:
       model_name = "meta-llama/Meta-Llama-3-8B-Instruct"
    print(model_name)
    # Load model & tokenizer
    # model_name = "/gscratch/socialrl/hjnam/contrastive_finetune/prism/" +  model_name
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype="auto",
        device_map="auto"  # will place layers automatically (useful for multi-GPU or CPU/GPU mix)
    )
    tokenizer = AutoTokenizer.from_pretrained(model_name)

    # f = pd.read_json("prism_i500.jsonl",lines=True)
    f = pd.read_json("prism500_qwen7b_scored.jsonl", lines=True)
    f = f.iloc[:200]
    # f = generations
    # Example prompt setup (chat-style)
    chosen_scores = []
    rejected_scores = []
    win_rate = 0
    tie_rate = 0
    for i, row in f.iterrows():
        prompt = row.chosen[0]["content"]
        chosen_response = row.chosen[1]["content"] # model generated
        rejected_response = row.rejected[1]["content"] # true chosen response
        for k, response in enumerate([chosen_response, rejected_response]):
            scores = []
            for preference in row.instructions.values():
                messages = [{"role": "system", "content": f"You are a helpful assistant, that evaluates another assistant's response based on how well the response is personalized to this user based on their stated preference. Give a score between 1 and 5, 1 if the response is general, and 5 if the response sufficiently addresses the user's preference. Only respond with a number between 1 and 5 and do not provide an explanation."},
                {"role": "user", "content": f"User: {prompt}\n\nAssistant: {response}\n\nUser's preference: {preference}"}]

                # Use the chat template helper in the tokenizer to build the input string
                text = tokenizer.apply_chat_template(
                    messages,
                    tokenize=False,
                    add_generation_prompt=True
                )
                # print("TEXT: ", text, "\n\n")
                # Tokenize and move to model device
                inputs = tokenizer([text], return_tensors="pt").to(model.device)

                # Generate
                generated = model.generate(
                    **inputs,
                    max_new_tokens=1024,
                    do_sample=True, 
                    top_p=0.9,
                    temperature=0.1,
                )

                # The output includes the entire sequence (input + response). We trim the input prefix.
                # (You can also separately generate only the suffix.)
                input_ids = inputs.input_ids
                generated_suffix = []
                for inp, out in zip(input_ids, generated):
                    # drop the input portion
                    generated_suffix.append(out[len(inp):])

                # Decode
                score_response = tokenizer.batch_decode(generated_suffix, skip_special_tokens=True)[0]
                # print("Response:", score_response)
                try:
                    score = int(score_response)
                    scores.append(score)
                except Exception as e:
                    print(e)
                    print(score_response, "\n\n")
            if k == 0:
                chosen_scores.append(np.mean(scores))
            else:
                rejected_scores.append(np.mean(scores))
                if chosen_scores[-1] >= rejected_scores[-1]:
                    tie_rate += 1
                if chosen_scores[-1] > rejected_scores[-1]:
                    win_rate += 1
        print("Win rate: ", win_rate / len(rejected_scores))
        print("Tie rate: ", tie_rate / len(rejected_scores))
    f["chosen_score"] = chosen_scores
    f["rejected_score"] = rejected_scores
    if use_qwen:
        f.to_json("prism500_qwen14b_scored.jsonl",lines=True,orient="records")
    # else:
    # f.to_json("prism500_llama8b_scored.jsonl",lines=True,orient="records")

    if use_qwen:
        print("Evaluating with QWEN")
    else:
        print("Evaluating with LLAMA")
    win_rate = win_rate / len(rejected_scores)
    tie_rate = tie_rate / len(rejected_scores)
    
    with open("results_prism.txt", "a") as f:
        f.write(save_name + " " + model_name + " " + str(tie_rate) + " " + str(win_rate) + "\n\n")


def generate(save_name, model_name, use_qwen):
    generator_name ="/gscratch/socialrl/hjnam/contrastive_finetune/prism/" + model_name
    print(generator_name)
    # generator_name = "Qwen/Qwen2.5-7B-Instruct"
    # generator_name = "meta-llama/Llama-3.2-1B-Instruct"
    # generator_name = "meta-llama/Meta-Llama-3-8B-Instruct"
    # Load model & tokenizer
    model = AutoModelForCausalLM.from_pretrained(
        generator_name,
        torch_dtype="auto",
        device_map="auto"  # will place layers automatically (useful for multi-GPU or CPU/GPU mix)
    )
    tokenizer = AutoTokenizer.from_pretrained(generator_name)
    
    if use_qwen:
        f = pd.read_json("prism/chosen_qwen14b_scored.jsonl", lines=True)
    else:
        f = pd.read_json("prism/chosen_llama8b_scored.jsonl", lines=True)
    
    generation = {"instruction": [], "prompt": [], "augmented_prompt": [], "response": []}
    for i, row in f.iterrows():
        prompt = row.chosen[0]["content"].strip()
        request = " ".join(extract_strings(row.instruction))
        print("REQUEST: ", request, '\n\n')
        augmented_prompt = f"Give me short 2-3 sentence answers to the following prompt: {prompt} Please respect the following requirements made by the user: {request} Respond with short 2-3 sentences."
        generation["prompt"].append(prompt)
        generation["instruction"].append(row.instruction)
        generation["augmented_prompt"].append(augmented_prompt)
    
        messages = [
            {"role": "user", "content": augmented_prompt}
        ]
        # Use the chat template helper in the tokenizer to build the input string
        text = tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True
        )

        # Tokenize and move to model device
        inputs = tokenizer([text], return_tensors="pt").to(model.device)

        # Generate
        generated = model.generate(
            **inputs,
            max_new_tokens=512,
            do_sample=True,
            top_p=0.9,
            temperature=0.1,
        )

        # The output includes the entire sequence (input + response). We trim the input prefix.
        # (You can also separately generate only the suffix.)
        input_ids = inputs.input_ids
        generated_suffix = []
        for inp, out in zip(input_ids, generated):
            # drop the input portion
            generated_suffix.append(out[len(inp):])

        # Decode
        response = tokenizer.batch_decode(generated_suffix, skip_special_tokens=True)[0]
        print("Response:", response)
        generation["response"].append(response)
    generation = pd.DataFrame(generation)
    generation.to_json(f"results/prism_{save_name}.jsonl", lines=True, orient="records")   

    # generation =  pd.read_json(f"results/prism_{save_name}.jsonl", lines=True)
    if use_qwen:
        model_name = "Qwen/Qwen2.5-14B-Instruct"
    else:
        model_name = "meta-llama/Meta-Llama-3-8B-Instruct"
    print(model_name)
    # Load model & tokenizer
    scorer = AutoModelForCausalLM.from_pretrained(
        model_name,
        torch_dtype="auto",
        device_map="auto"  # will place layers automatically (useful for multi-GPU or CPU/GPU mix)
    )
    scorer_tokenizer = AutoTokenizer.from_pretrained(model_name)

    if use_qwen:
        oracle = pd.read_json("prism/chosen_qwen14b_scored.jsonl",lines=True)
    else:
        oracle = pd.read_json("prism/chosen_llama8b_scored.jsonl",lines=True)
    oracle = oracle.iloc[:200]
    generation = pd.DataFrame(generation)
    response_score = []
    for i, row in generation.iterrows():
        scores = []
        prompt = row.prompt
        response = row.response
        for preference in row.instruction.values():
            messages = [{"role": "system", "content": f"You are a helpful assistant, that evaluates another assistant's response based on how well the response is personalized to this user based on their stated preference. Give a score between 1 and 5, 1 if the response is general, and 5 if the response sufficiently addresses the user's preference. Only respond with a number between 1 and 5 and do not provide an explanation."},
                {"role": "user", "content": f"User: {prompt}\n\nAssistant: {response}\n\nUser's preference: {preference}"}]

            # Use the chat template helper in the tokenizer to build the input string
            text = scorer_tokenizer.apply_chat_template(
                    messages,
                    tokenize=False,
                    add_generation_prompt=True
                    )
            inputs = scorer_tokenizer([text], return_tensors="pt").to(scorer.device)

            # Generate
            generated = scorer.generate(
                        **inputs,
                        max_new_tokens=1024,
                        do_sample=True, 
                        top_p=0.9,
                        temperature=0.1,
                        )

            input_ids = inputs.input_ids
            generated_suffix = []
            for inp, out in zip(input_ids, generated):
                # drop the input portion
                generated_suffix.append(out[len(inp):])

            # Decode
            score_response = scorer_tokenizer.batch_decode(generated_suffix, skip_special_tokens=True)[0]
            score = 0
            try:
                score = int(re.search(r'\d+', score_response).group())
                scores.append(score)
            except Exception as e:
                print(e)
                print(score_response, "\n\n")
        response_score.append(np.mean(scores))
    generation["score"] = response_score
    generation["chosen_score"] = oracle.chosen_score.tolist()
    generation.to_json(f"results/prism_{save_name}.jsonl", lines=True, orient="records")
    win_rate = len(np.where(oracle["chosen_score"] <= generation["score"])[0]) / len(generation["score"]) * 100
    
    print("Win rate: ", win_rate)
    with open("ablations_icml/results_prism.txt", "a") as f:
        f.write(save_name + " " + model_name + " " + str(win_rate) + "\n\n")

def dpo_dataset():
    generator_name = "Qwen/Qwen2.5-7B-Instruct"
    # generator_name = "meta-llama/Llama-3.2-3B-Instruct"
    # generator_name = "meta-llama/Meta-Llama-3-8B-Instruct"
    
    # Load model & tokenizer
    model = AutoModelForCausalLM.from_pretrained(
        generator_name,
        torch_dtype="auto",
        device_map="auto"  # will place layers automatically (useful for multi-GPU or CPU/GPU mix)
    )
    tokenizer = AutoTokenizer.from_pretrained(generator_name)
    df = {"prompt": [], "chosen": [], "rejected": []}
    f = pd.read_json("prism_full_train.jsonl",lines=True)
    # generate using the augmented prompt
    for i, row in f.iterrows():
        prompt = row.chosen[0]["content"].strip()
        request = " ".join(extract_strings(row.instructions))
        print("REQUEST: ", request, '\n\n')
        augmented_prompt = f"Give me short 2-3 sentence answers to the following prompt: {prompt} Please respect the following requirements made by the user: {request} Respond with short 2-3 sentences."
        df["prompt"].append(augmented_prompt)
        base_prompt = f"Give me short 2-3 sentence answers to the following prompt: {prompt} Respond with short 2-3 sentences."
        messages = [
            {"role": "user", "content": augmented_prompt}
        ]
        # Use the chat template helper in the tokenizer to build the input string
        text = tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True
        )

        # Tokenize and move to model device
        inputs = tokenizer([text], return_tensors="pt").to(model.device)

        # Generate
        generated = model.generate(
            **inputs,
            max_new_tokens=512,
            do_sample=True,
            top_p=0.9,
            temperature=0.1,
        )

        # The output includes the entire sequence (input + response). We trim the input prefix.
        # (You can also separately generate only the suffix.)
        input_ids = inputs.input_ids
        generated_suffix = []
        for inp, out in zip(input_ids, generated):
            # drop the input portion
            generated_suffix.append(out[len(inp):])

        # Decode
        response = tokenizer.batch_decode(generated_suffix, skip_special_tokens=True)[0]
        print("Chosen Response:", response)
        df["chosen"].append([{"role": "user", "content": augmented_prompt}, {"role": "assistant", "content": response}])
    

        # generate using the base prompt 
        messages = [
            {"role": "user", "content": base_prompt}
        ]
        # Use the chat template helper in the tokenizer to build the input string
        text = tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True
        )

        # Tokenize and move to model device
        inputs = tokenizer([text], return_tensors="pt").to(model.device)

        # Generate
        generated = model.generate(
            **inputs,
            max_new_tokens=512,
            do_sample=True,
            top_p=0.9,
            temperature=0.1,
        )

        # The output includes the entire sequence (input + response). We trim the input prefix.
        # (You can also separately generate only the suffix.)
        input_ids = inputs.input_ids
        generated_suffix = []
        for inp, out in zip(input_ids, generated):
            # drop the input portion
            generated_suffix.append(out[len(inp):])

        # Decode
        response = tokenizer.batch_decode(generated_suffix, skip_special_tokens=True)[0]
        print("Rejected Response:", response)
        df["rejected"].append([{"role": "user", "content": augmented_prompt}, {"role": "assistant", "content": response}])
    df = pd.DataFrame(df)
    df.to_json("prism/qwen7b_dpo/train.jsonl",lines=True, orient="records")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Example script with argparse")

    # Add arguments
    parser.add_argument("--save_name", type=str, default="")
    parser.add_argument("--model_checkpoint", type=str, default="")
    parser.add_argument("--use_qwen", action="store_true", default=False, help="Use toy domain for eval")
    
    args = parser.parse_args()
    generate(save_name=args.save_name, model_name=args.model_checkpoint, use_qwen=args.use_qwen)
