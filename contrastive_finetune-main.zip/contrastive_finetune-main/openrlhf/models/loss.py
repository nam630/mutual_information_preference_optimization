from typing import Optional, Tuple

import torch
import torch.distributed as dist
import torch.nn as nn
import torch.nn.functional as F

from .utils import masked_mean


class GPTLMLoss(nn.Module):
    """
    GPT Language Model Loss
    """

    def __init__(self, ring_attn_group=None):
        super().__init__()
        self.IGNORE_INDEX = -100
        self.loss = nn.CrossEntropyLoss(ignore_index=self.IGNORE_INDEX)

        self.ring_attn_group = ring_attn_group
        if self.ring_attn_group:
            self.ring_attn_rank = dist.get_rank(self.ring_attn_group)
            self.ring_attn_world_size = dist.get_world_size(self.ring_attn_group)

    def forward(self, logits: torch.Tensor, labels: torch.Tensor) -> torch.Tensor:
        # RingAttention
        if self.ring_attn_group is not None:
            total_seq_len = labels.size(-1)
            seq_len_per_process = total_seq_len // self.ring_attn_world_size
            start_idx = self.ring_attn_rank * seq_len_per_process
            end_idx = min(start_idx + seq_len_per_process, total_seq_len)
            labels = labels[..., start_idx:end_idx]

            shift_logits = logits[..., :-1, :].contiguous()
            shift_labels = labels[..., 1:].contiguous()

            # if labels are all IGNORE_INDEX, then nn.CrossEntropyLoss will be nan
            if torch.all(shift_labels == self.IGNORE_INDEX):
                # Use mean of logits multiplied by 0 to maintain gradient flow
                loss = shift_logits.mean() * 0
            else:
                loss = self.loss(shift_logits.view(-1, shift_logits.size(-1)), shift_labels.view(-1))

            dist.all_reduce(loss, op=dist.ReduceOp.SUM, group=self.ring_attn_group)
            loss = loss / self.ring_attn_world_size
        else:
            shift_logits = logits[..., :-1, :].contiguous()
            shift_labels = labels[..., 1:].contiguous()

            loss = self.loss(shift_logits.view(-1, shift_logits.size(-1)), shift_labels.view(-1))

        return loss


class PolicyLoss(nn.Module):
    """
    Policy Loss for PPO
    """

    def __init__(self, clip_eps: float = 0.2) -> None:
        super().__init__()
        self.clip_eps = clip_eps

    def forward(
        self,
        log_probs: torch.Tensor,
        old_log_probs: torch.Tensor,
        advantages: torch.Tensor,
        action_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        ratio = (log_probs - old_log_probs).exp()
        surr1 = ratio * advantages
        surr2 = ratio.clamp(1 - self.clip_eps, 1 + self.clip_eps) * advantages
        loss = -torch.min(surr1, surr2)
        loss = masked_mean(loss, action_mask, dim=-1).mean()
        return loss


class ValueLoss(nn.Module):
    """
    Value Loss for PPO
    """

    def __init__(self, clip_eps: float = None) -> None:
        super().__init__()
        self.clip_eps = clip_eps

    def forward(
        self,
        values: torch.Tensor,
        old_values: torch.Tensor,
        returns: torch.Tensor,
        action_mask: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        if self.clip_eps is not None:
            values_clipped = old_values + (values - old_values).clamp(-self.clip_eps, self.clip_eps)
            surr1 = (values_clipped - returns) ** 2
            surr2 = (values - returns) ** 2
            loss = torch.max(surr1, surr2)
        else:
            loss = (values - returns) ** 2

        loss = masked_mean(loss, action_mask, dim=-1).mean()
        return 0.5 * loss

class RegressionLoss(nn.Module):
    """
    Regression Loss for Reward Model if given as (x, y)
    """

    def forward(
        self, pred_reward: torch.Tensor, true_reward: torch.Tensor = None
    ) -> torch.Tensor:
        loss = (pred_reward - true_reward) ** 2
        return loss.mean()


class BinaryLoss(nn.Module):
    """
    Binary (0, 1) classification loss for Positive User Reward Model. 
    1 = positive sentiment
    0 = negative sentiment
    """

    def __init__(self):
        super().__init__()
        # applies BCE independently to each output
        self.loss_fn = nn.BCEWithLogitsLoss()

    def forward(
        self, pred_reward: torch.Tensor, true_reward: torch.Tensor
    ) -> torch.Tensor:
        """
        pred_reward: [batch, 3] raw logits from the model
        true_reward: [batch, 3] with values in {0,1}
        """
        return self.loss_fn(pred_reward, true_reward.float())

class MultiHeadedClassificationLoss(nn.Module):
    """
    Multi-label classification loss for Reward Model with 3 binary outputs.
    """

    def __init__(self):
        super().__init__()
        # applies BCE independently to each output
        self.loss_fn = nn.BCEWithLogitsLoss()

    def forward(
        self, pred_reward: torch.Tensor, true_reward: torch.Tensor
    ) -> torch.Tensor:
        """
        pred_reward: [batch, 3] raw logits from the model
        true_reward: [batch, 3] with values in {0,1}
        """
        return self.loss_fn(pred_reward, true_reward.float())

class PairWiseLoss(nn.Module):
    """
    Pairwise Loss for Reward Model
    """

    def forward(
        self, chosen_reward: torch.Tensor, reject_reward: torch.Tensor, margin: torch.Tensor = None
    ) -> torch.Tensor:
        if margin is not None:
            loss = -F.logsigmoid(chosen_reward - reject_reward - margin)
        else:
            loss = -F.logsigmoid(chosen_reward - reject_reward)
        return loss.mean()


class LogExpLoss(nn.Module):
    """
    Pairwise Loss for Reward Model
    Details: https://arxiv.org/abs/2204.05862
    """

    def forward(
        self, chosen_reward: torch.Tensor, reject_reward: torch.Tensor, margin: torch.Tensor = None
    ) -> torch.Tensor:
        loss = torch.log(1 + torch.exp(reject_reward - chosen_reward)).mean()
        return loss

class SAMILoss(nn.Module):
    """
    SAMI Loss adapted to match InfoNCELoss interface.
    Builds the (2x2) logprobs matrix from the four pairwise log-probs
    and applies the original row+col cross-entropy formulation.
    """

    def __init__(self, label_smoothing: float = 0.0) -> None:
        super().__init__()
        self.label_smoothing = label_smoothing

    def forward(
        self,
        chosen_chosen_logps: torch.Tensor,       # l1: score(const_0, resp_0)
        chosen_rejected_logps: torch.Tensor,     # l2: score(const_0, resp_1)
        rejected_chosen_logps: torch.Tensor,     # l3: score(const_1, resp_0)
        rejected_rejected_logps: torch.Tensor,   # l4: score(const_1, resp_1)
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:

        # Build (batch, n_constitutions=2, n_responses=2) matrix
        # Each batch element gets its own 2x2 logprobs grid
        logprobs = torch.stack([
            torch.stack([chosen_chosen_logps,   chosen_rejected_logps],  dim=1),  # row 0: chosen constitution
            torch.stack([rejected_chosen_logps, rejected_rejected_logps], dim=1), # row 1: rejected constitution
        ], dim=1)  # shape: (batch, 2, 2)

        loss = self._sami_loss(logprobs)
        return loss

    def _sami_loss(self, logprobs: torch.FloatTensor) -> torch.FloatTensor:
        """
        Args:
            logprobs: Shape (batch, n_constitutions=2, n_responses=2)
        Returns:
            loss: Scalar mean loss over batch.
        """
        # Row loss: for each constitution, find its matching response (diagonal)
        logsumexp_row = torch.logsumexp(logprobs, dim=2, keepdim=True)  # across responses
        logits_row = logprobs - logsumexp_row                            # (batch, 2, 2)
        # label i = column i is the correct response for constitution i
        labels_row = torch.arange(logprobs.shape[1], dtype=torch.long, device=logprobs.device)
        labels_row = labels_row.unsqueeze(0).expand(logprobs.shape[0], -1)  # (batch, 2)
        loss_row = F.cross_entropy(
            logits_row.view(-1, logprobs.shape[2]),   # (batch*2, 2)
            labels_row.reshape(-1),                    # (batch*2,)
            label_smoothing=self.label_smoothing,
        )

        # Col loss: for each response, find its matching constitution (diagonal)
        logsumexp_col = torch.logsumexp(logprobs, dim=1, keepdim=True)  # across constitutions
        logits_col = logprobs - logsumexp_col                            # (batch, 2, 2)
        logits_col_t = logits_col.transpose(1, 2)                        # (batch, 2, 2) transposed
        labels_col = torch.arange(logprobs.shape[2], dtype=torch.long, device=logprobs.device)
        labels_col = labels_col.unsqueeze(0).expand(logprobs.shape[0], -1)  # (batch, 2)
        loss_col = F.cross_entropy(
            logits_col_t.reshape(-1, logprobs.shape[1]),  # (batch*2, 2)
            labels_col.reshape(-1),                        # (batch*2,)
            label_smoothing=self.label_smoothing,
        )

        return (loss_row + loss_col) / 2

class InfoNCELoss(nn.Module):
     """
     InfoNCE Loss
     From https://github.com/janphilippfranken/sami/blob/main/src/sami/trainers/sami_trainer.py#L35 (SAMI loss)
     """

     def __init__(self, beta: float, label_smoothing: float = 0.0, ipo: bool = False) -> None:
         super().__init__()
         self.beta = beta
         self.label_smoothing = label_smoothing

     def forward(
         self,
         chosen_chosen_logps: torch.Tensor,
         chosen_rejected_logps: torch.Tensor,
         rejected_chosen_logps: torch.Tensor,
         rejected_rejected_logps: torch.Tensor,
     ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
         
        temperature = 100.0 # typically uses 0.1 or <1,but with 1 already vanishing gradient
        # chosen response p(chosen|chosen context) / p(chosen|chosen context) + p(chosen|rejected context)
        norm_const = torch.logsumexp(torch.stack([chosen_chosen_logps, chosen_rejected_logps, rejected_chosen_logps, rejected_rejected_logps]), dim=0)
        print("norm const: ", norm_const, "\n")
        loss_chosen = F.cross_entropy(
            (torch.stack([chosen_chosen_logps, rejected_chosen_logps], dim=1) - norm_const) / temperature,
            torch.zeros_like(chosen_chosen_logps, dtype=torch.long),
            )
        
        # chosen response p(rejected|rejected context) / p(rejected|chosen context) + p(rejected|rejected context)
        loss_rejected = F.cross_entropy(
            (torch.stack([rejected_rejected_logps, chosen_rejected_logps], dim=1) - norm_const) / temperature,
            torch.zeros_like(rejected_rejected_logps, dtype=torch.long),
            )

        loss = (loss_chosen + loss_rejected) / 2
        print("infoNCE loss: ", loss)
        return loss

class DPOLoss(nn.Module):
    """
    DPO Loss
    """

    def __init__(self, beta: float, label_smoothing: float = 0.0, ipo: bool = False) -> None:
        super().__init__()
        self.beta = beta
        self.label_smoothing = label_smoothing
        self.ipo = ipo

    def forward(
        self,
        policy_chosen_logps: torch.Tensor,
        policy_rejected_logps: torch.Tensor,
        reference_chosen_logps: torch.Tensor,
        reference_rejected_logps: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        pi_logratios = policy_chosen_logps - policy_rejected_logps
        ref_logratios = reference_chosen_logps - reference_rejected_logps
        logits = pi_logratios - ref_logratios

        if self.ipo:
            losses = (logits - 1 / (2 * self.beta)) ** 2  # Eq. 17 of https://arxiv.org/pdf/2310.12036v2.pdf
        else:
            # Eq. 3 https://ericmitchell.ai/cdpo.pdf; label_smoothing=0 gives original DPO (Eq. 7 of https://arxiv.org/pdf/2305.18290.pdf)
            losses = (
                -F.logsigmoid(self.beta * logits) * (1 - self.label_smoothing)
                - F.logsigmoid(-self.beta * logits) * self.label_smoothing
            )

        loss = losses.mean()
        chosen_rewards = self.beta * (policy_chosen_logps - reference_chosen_logps).detach()
        rejected_rewards = self.beta * (policy_rejected_logps - reference_rejected_logps).detach()

        return loss, chosen_rewards, rejected_rewards


# Adapted from https://github.com/ContextualAI/HALOs/blob/ca9b7e3eeea220c0944ad8095d641da33f907a7e/trainers.py#L742
class VanillaKTOLoss(nn.Module):
    """
    KTO loss for even sampling
    """

    def __init__(self, beta: float) -> None:
        super().__init__()
        self.beta = beta

    def forward(
        self,
        policy_chosen_logps: torch.FloatTensor,
        policy_rejected_logps: torch.FloatTensor,
        reference_chosen_logps: torch.FloatTensor,
        reference_rejected_logps: torch.FloatTensor,
    ) -> Tuple[torch.FloatTensor, torch.FloatTensor, torch.FloatTensor]:
        chosen_KL = (policy_chosen_logps - reference_chosen_logps).mean().clamp(min=0)
        rejected_KL = (policy_rejected_logps - reference_rejected_logps).mean().clamp(min=0)

        chosen_logratios = policy_chosen_logps - reference_chosen_logps
        rejected_logratios = policy_rejected_logps - reference_rejected_logps

        losses = torch.cat(
            (
                1 - F.sigmoid(self.beta * (chosen_logratios - rejected_KL)),
                1 - F.sigmoid(self.beta * (chosen_KL - rejected_logratios)),
            ),
            0,
        ).mean()

        chosen_rewards = self.beta * (policy_chosen_logps - reference_chosen_logps).detach()
        rejected_rewards = self.beta * (policy_rejected_logps - reference_rejected_logps).detach()
        return losses, chosen_rewards, rejected_rewards


# Adapted from https://github.com/ContextualAI/HALOs/blob/ca9b7e3eeea220c0944ad8095d641da33f907a7e/trainers.py#L770
class KTOLoss(nn.Module):
    """
    KTO loss for uneven sampling
    """

    def __init__(
        self, beta: float, desirable_weight: float, undesirable_weight: float, world_size: int, device: torch.device
    ) -> None:
        super().__init__()
        self.beta = beta
        self.world_size = world_size
        self.device = device
        self.desirable_weight = desirable_weight
        self.undesirable_weight = undesirable_weight

    def forward(
        self,
        policy_chosen_logps: torch.FloatTensor,
        policy_rejected_logps: torch.FloatTensor,
        policy_KL_logps: torch.FloatTensor,
        reference_chosen_logps: torch.FloatTensor,
        reference_rejected_logps: torch.FloatTensor,
        reference_KL_logps: torch.FloatTensor,
    ) -> Tuple[torch.FloatTensor, torch.FloatTensor, torch.FloatTensor]:
        KL = (policy_KL_logps - reference_KL_logps).mean().detach()
        # all_reduce sums up the KL estimates across all devices (gradient will also be scaled by world size)
        dist.all_reduce(KL, op=dist.ReduceOp.SUM)
        # take average (will also scale gradients appropriately)
        KL = (KL / self.world_size).clamp(min=0)

        if policy_chosen_logps.shape[0] != 0:
            chosen_logratios = policy_chosen_logps - reference_chosen_logps
            chosen_losses = 1 - F.sigmoid(self.beta * (chosen_logratios - KL))
            chosen_rewards = self.beta * chosen_logratios.detach()
        else:
            # important to cast to policy_dtype; otherwise error will occur during all_gather
            chosen_losses = torch.Tensor([]).to(policy_rejected_logps.dtype).to(self.device)
            chosen_rewards = torch.Tensor([]).to(policy_rejected_logps.dtype).to(self.device)

        if policy_rejected_logps.shape[0] != 0:
            rejected_logratios = policy_rejected_logps - reference_rejected_logps
            rejected_losses = 1 - F.sigmoid(self.beta * (KL - rejected_logratios))
            rejected_rewards = self.beta * rejected_logratios.detach()
        else:
            # important to cast to policy_dtype; otherwise error will occur during all_gather
            rejected_losses = torch.Tensor([]).to(policy_chosen_logps.dtype).to(self.device)
            rejected_rewards = torch.Tensor([]).to(policy_chosen_logps.dtype).to(self.device)

        losses = torch.cat(
            (self.desirable_weight * chosen_losses, self.undesirable_weight * rejected_losses), 0
        ).mean()
        return losses, chosen_rewards, rejected_rewards, KL


# Adapted from https://github.com/microsoft/LMOps/blob/main/minillm/finetune.py#L166
class KDLoss(nn.Module):
    """
    Language Model Knowledge Distillation Loss
    """

    def __init__(self):
        super().__init__()
        self.IGNORE_INDEX = -100

    def forward(self, logits: torch.Tensor, teacher_logits: torch.Tensor, label: torch.Tensor) -> torch.Tensor:
        teacher_probs = F.softmax(teacher_logits, dim=-1, dtype=torch.float32)
        inf_mask = torch.isinf(logits)
        logprobs = F.log_softmax(logits, dim=-1, dtype=torch.float32)
        prod_probs = torch.masked_fill(teacher_probs * logprobs, inf_mask, 0)
        x = torch.sum(prod_probs, dim=-1).view(-1)
        mask = (label != self.IGNORE_INDEX).int()
        distil_loss = -torch.sum(x * mask.view(-1), dim=0) / torch.sum(mask.view(-1), dim=0)

        return distil_loss


class PRMLoss(nn.Module):
    """
    Process Reward Model Loss
    """

    def __init__(self, placeholder_token_id: int, reward_token_ids: Optional[list[int]] = None):
        super().__init__()
        self.IGNORE_INDEX = -100
        self.loss = nn.CrossEntropyLoss(ignore_index=self.IGNORE_INDEX)
        self.placeholder_token_id = placeholder_token_id
        self.reward_token_ids = reward_token_ids

    def forward(self, inputs: torch.Tensor, logits: torch.Tensor, labels: torch.Tensor, *, return_acc: bool = False):
        placeholder_mask = inputs == self.placeholder_token_id
        logits = logits[placeholder_mask]
        labels = labels[placeholder_mask]

        if labels.dtype == torch.float:
            # soft label
            assert len(self.reward_token_ids) == 2, "reward_token_ids should have 2 tokens for soft labels"
            logits = logits[..., self.reward_token_ids]
            positive_labels = labels.to(logits.dtype)
            negative_labels = 1 - positive_labels
            negative_labels[positive_labels != -100] = 1 - positive_labels[positive_labels != -100]
            labels = torch.stack([positive_labels, negative_labels], dim=-1)
        elif self.reward_token_ids is not None:
            # hard label with reward_token_ids set. (otherwise the whole vocab will be trained together.)
            logits = logits[..., self.reward_token_ids]
            # this is slow....
            for i, token in enumerate(self.reward_token_ids):
                labels = torch.where(labels == token, i, labels)

        loss = self.loss(logits, labels)
        if not return_acc:
            return loss

        if labels.dtype == logits.dtype:
            labels = labels.argmax(dim=-1)
        acc = (logits.argmax(dim=-1) == labels).float().mean()
        return loss, acc
